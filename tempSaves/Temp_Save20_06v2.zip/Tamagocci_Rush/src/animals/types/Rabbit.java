package animals.types;

import animals.general.Herbivore;

public class Rabbit extends Herbivore {


}
