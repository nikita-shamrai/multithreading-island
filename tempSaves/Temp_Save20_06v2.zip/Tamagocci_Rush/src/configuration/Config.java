package configuration;

import lombok.Getter;
import lombok.Setter;
import java.util.List;

@Getter
//@Setter
public class Config {

    private int areaHeight;
    private int areaWidth;
    private int plantsMaxQuantityForCell;
    private int plantQuantity;
    private int plantLiveTime;
    private int simulationDuration;

    private List<animalConfigurations> animalConfigurations; //List animal or animalConfig? Check yaml

    public void setPlantQuantity(int plantQuantity) {
        this.plantQuantity = plantQuantity;
    }


}
