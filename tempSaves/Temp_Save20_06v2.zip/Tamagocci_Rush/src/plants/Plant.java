package plants;

import java.time.LocalTime;

public class Plant {

    private final String plantEmoji = "\uD83C\uDF3F";
    private final LocalTime plantCreationTime = LocalTime.now();
    private double plantValue; // пока не используется

}
