package multithreading;

public class plantsThread implements Runnable{
    
    @Override
    public void run() {

    }
}
