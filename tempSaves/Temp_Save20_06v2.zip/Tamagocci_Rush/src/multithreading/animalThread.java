package multithreading;

public class animalThread implements Runnable{
    @Override
    public void run() {

    }
}
