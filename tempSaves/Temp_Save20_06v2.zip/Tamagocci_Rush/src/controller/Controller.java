package controller;

import animals.general.Animal;
import area_and_cell.Area;
import area_and_cell.Cell;
import configuration.Config;
import configuration.YamlParser;
import initialization.AnimalInitialization;
import initialization.AreaInitialization;
import initialization.PlantsInitialization;
import util.MainSingleton;
import java.util.Collections;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

public class Controller {

    private Config config;
    private Area area;
    private final MainSingleton mainSingleton = MainSingleton.getInstance();

    public void startApp() {
        YamlParser yamlParser = new YamlParser("src/configuration.yaml");
        this.config = yamlParser.configInitialize();

        AreaInitialization areaInitialization = new AreaInitialization(config);
        this.area = areaInitialization.areaInitialization();

        PlantsInitialization plantsInitialization = new PlantsInitialization(config, area);
        plantsInitialization.fillAreaWithPlants();

        AnimalInitialization animalInitialization = new AnimalInitialization(config, area);
        animalInitialization.animalInitialize();
        animalInitialization.fillAreaWithAnimals();

        animalActions();

        System.out.println("TOTAL PLANTS - " + mainSingleton.getPlantList().size());
        System.out.println("TOTAL ANIMALS - " + mainSingleton.getAnimalList().size());
    }

    //TEMP CHECK
    private void temporaryCheckPLANTSMethod() {
        for (int i = 0; i < area.getAreaCells().length; i++) {
            System.out.println();
            for (int j = 0; j < area.getAreaCells()[i].length; j++) {
                System.out.print("\t" + area.getAreaCells()[i][j].getPlants().size());
            }
        }
        System.out.println();
    }
    //TEMP CHECK
    private void temporaryCheckANIMALSMethod() {
        for (int i = 0; i < area.getAreaCells().length; i++) {
            System.out.println();
            for (int j = 0; j < area.getAreaCells()[i].length; j++) {
                if (area.getAreaCells()[i][j].getAnimals().size() > 0) {
                    System.out.print("\t" + area.getAreaCells()[i][j].getAnimals().size());
                }
                else System.out.print("\t" + "-");
                }

            }
            System.out.println();
        }

    private void animalActions(){
        Cell[][] cells = area.getAreaCells();
        for (int i = 0; i < cells.length; i++) {
            for (int j = 0; j < cells[i].length; j++) {
                CopyOnWriteArrayList<Animal> animals = cells[i][j].getAnimals();
                Collections.shuffle(animals);
                for (int k = 0; k < animals.size(); k++) {
                    if (animals.get(k) == null) {
                        continue;
                    }
                    Animal animal = animals.get(k);
                    int cordX = animal.getCordX();
                    int cordY = animal.getCordY();
                    animal.reproduction();
                    animal.eat();
                    animal.move();
                    int newCordX = animal.getCordX();
                    int newCordY = animal.getCordY();
                    if (cordX != newCordX || cordY != newCordY) {
                        animals.set(k, null);
                        cells[newCordY][newCordX].getAnimals().add(animal);
                    }
                }
                animals = animals.stream()
                        .filter(Objects::nonNull)
                        .collect(Collectors.toCollection(CopyOnWriteArrayList::new));
                cells[i][j].setAnimals(animals);
            }
        }
    }

}
