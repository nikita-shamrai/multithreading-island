package plants;

import java.time.LocalTime;
import java.util.Timer;

public class Plant {

    private final String plantEmoji = "\uD83C\uDF3F";
    private final LocalTime plantCreationTime = LocalTime.now();
    private double plantValue;

}
