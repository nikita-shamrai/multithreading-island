package animals.types;

import animals.general.Herbivore;

public class Goat extends Herbivore {


}
