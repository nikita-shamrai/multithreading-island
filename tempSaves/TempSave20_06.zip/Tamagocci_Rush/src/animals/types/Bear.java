package animals.types;

import animals.general.Animal;
import animals.general.Predator;
import lombok.Builder;


public class Bear extends Predator {


}
