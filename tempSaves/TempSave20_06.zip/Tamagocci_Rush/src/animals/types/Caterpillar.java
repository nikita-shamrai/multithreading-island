package animals.types;

import animals.general.Herbivore;

public class Caterpillar extends Herbivore {



}
