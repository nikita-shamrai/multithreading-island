package animals.types;

import animals.general.Predator;

public class Wolf extends Predator {




}
