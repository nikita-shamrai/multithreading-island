package animals.types;

import animals.general.Predator;

public class Eagle extends Predator {


}
