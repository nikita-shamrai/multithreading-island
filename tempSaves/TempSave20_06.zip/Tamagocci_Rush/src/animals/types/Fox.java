package animals.types;

import animals.general.Predator;

public class Fox extends Predator {


}
